/**
 * 
 */
package raceFiles;

/**
 * @author a4432_asu
 *
 */
public class Tortoise extends Racer {

	/**
	 * @param name
	 * @param minSpeedInMetersPerSecond
	 * @param maxSpeedInMetersPerSecon
	 */
	public Tortoise(String name, double minSpeedInMetersPerSecond, double maxSpeedInMetersPerSecon) {
		super(name, minSpeedInMetersPerSecond, maxSpeedInMetersPerSecon);
		// TODO Auto-generated constructor stub
	}
	
}
